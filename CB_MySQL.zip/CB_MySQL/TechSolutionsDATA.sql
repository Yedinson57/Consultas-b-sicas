-- Consultas de la DATA REGISTRADA
-- CONSULTAS BÁSICAS (10)
USE TechSolutions;

-- 1. Listar todos los empleados
-- (muestra todos los campos de la tabla Empleado)
SELECT * FROM Empleado;

-- 2. Mostrar nombres y correos de empleados
SELECT Id_Empleado, Nombre, Segundo_Nombre, Apellido, Segundo_Apellido, Email
FROM Empleado;

-- 3. WHERE con igualdad: Empleados del departamento de TI (id = 1)
SELECT Id_Empleado, Nombre, Apellido, Id_Departamento
FROM Empleado
WHERE Id_Departamento = 1;

-- 4. WHERE con AND: Empleados mujeres del departamento de TI
SELECT Id_Empleado, Nombre, Apellido, Sexo, Id_Departamento
FROM Empleado
WHERE Id_Departamento = 1 AND Sexo = "F";

-- 5. WHERE con OR: Empleados de TI o Marketing
-- Supongamos Marketing es id = 2 (ver INSERT de departamentos)
SELECT Id_Empleado, Nombre, Apellido, Id_Departamento
FROM Empleado
WHERE Id_Departamento = 1 OR Id_Departamento = 2;

-- 6. LIKE con %: Empleados cuyo apellido empieza con 'M'
SELECT Id_Empleado, Nombre, Apellido
FROM Empleado
WHERE Apellido LIKE "M%";

-- 7. BETWEEN: Empleados contratados entre 2020 y 2022
SELECT Id_Empleado, Nombre, Apellido, Fecha_Contratacion
FROM Empleado
WHERE Fecha_Contratacion BETWEEN "2020-01-01" AND "2022-12-31";

-- 8. Mayor que: Cargos con salario base mayor a 4000
SELECT Id_Cargo, Nombre_Cargo, Salario_Base
FROM Cargo
WHERE Salario_Base > 4000.00;

-- 9. Menor que: Empleados nacidos después de 1990
-- (nacidos después de 1990 -> Fecha_Nacimiento > '1990-12-31')
SELECT Id_Empleado, Nombre, Apellido, Fecha_Nacimiento
FROM Empleado
WHERE Fecha_Nacimiento > "1990-12-31";

-- 10. Combinación de condiciones: Empleados cuyo apellido empieza con 'M' y contratados después de 2018
SELECT Id_Empleado, Nombre, Apellido, Fecha_Contratacion
FROM Empleado
WHERE Apellido LIKE "M%" AND Fecha_Contratacion > "2018-12-31";

-- Empleados con su departamento y cargo
SELECT e.Id_Empleado, CONCAT(e.Nombre, ' ', e.Apellido) AS Nombre_Completo,
       d.Nombre AS Departamento, c.Nombre_Cargo, c.Salario_Base
FROM Empleado e
LEFT JOIN Departamento d ON e.Id_Departamento = d.Id_Departamento
LEFT JOIN Cargo c ON e.Id_Cargo = c.Id_Cargo;

-- Listado de proyectos con empleados asignados (JOIN N:M)
SELECT p.Id_Proyecto, p.Nombre_Proyecto, e.Id_Empleado, CONCAT(e.Nombre, ' ', e.Apellido) AS Empleado, ep.Rol
FROM Proyecto p
JOIN Empleado_Proyecto ep ON p.Id_Proyecto = ep.Id_Proyecto
JOIN Empleado e ON ep.Id_Empleado = e.Id_Empleado
ORDER BY p.Id_Proyecto;
