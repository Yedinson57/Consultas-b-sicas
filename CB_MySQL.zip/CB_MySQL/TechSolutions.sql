-- vamos a crear la base de datos
CREATE DATABASE IF NOT EXISTS TechSolutions;
-- voy a utilizar la base de datos creada
Use TechSolutions;
-- creamos la primer tabla independiente para la primer entidad independiente del modelo MER
-- Usamos AUTO_INCREMENT para el id, es decir que empiece desde 1 hasta donde vayamos a insertar data
CREATE TABLE IF NOT EXISTS Departamento(
Id_Departamento INT NOT NULL AUTO_INCREMENT,
Nombre VARCHAR(100) NOT NULL,
Ubicacion VARCHAR(100),
Telefono VARCHAR(20)
);
-- creamos la segunda tabla independiente para la segunda entidad independiente del modelo MER
CREATE TABLE IF NOT EXISTS Cargo(
Id_Cargo INT NOT NULL AUTO_INCREMENT,
Nombre_Cargo VARCHAR(100) NOT NULL,
Salario_Base DECIMAL(10,2) NOT NULL,
Descripcion VARCHAR(200)
);
-- creamos la primer tabla dependiente para la primer entidad dependiente del modelo MER
CREATE TABLE IF NOT EXISTS Empleado(
Id_Empleado INT NOT NULL AUTO_INCREMENT,
Nombre VARCHAR(50) NOT NULL,
Segundo_Nombre VARCHAR(50),
Apellido VARCHAR(50) NOT NULL,
Segundo_Apellido VARCHAR(50),
Sexo VARCHAR(10),
Fecha_Nacimiento DATE,
Fecha_Contratacion DATE,
Email VARCHAR(100),
Id_Departamento INT,
Id_Cargo INT,
FOREIGN KEY (Id_Departamento) REFERENCES Departamento(Id_Departamento),
FOREIGN KEY (Id_Cargo) REFERENCES Cargo(Id_Cargo)
);

-- creamos la tercer tabla independiente para la tercer entidad independiente del modelo MER
CREATE TABLE IF NOT EXISTS Proyecto(
Id_Proyecto INT NOT NULL AUTO_INCREMENT,
Nombre_Proyecto VARCHAR(150) NOT NULL,
Fecha_Inicio DATE,
Fecha_Fin DATE,
Estado VARCHAR(30)
);

-- creamos la segunda tabla dependiente para la segunda entidad dependiente del modelo MER
CREATE TABLE IF NOT EXISTS Empleado_Proyecto (
Id_EP INT NOT NULL AUTO_INCREMENT,
Id_Empleado INT NOT NULL,
Id_Proyecto INT NOT NULL,
Rol VARCHAR(80),
Fecha_Entrada DATE,
Fecha_Salida DATE,
FOREIGN KEY (Id_Empleado) REFERENCES Empleado(Id_Empleado),
FOREIGN KEY (Id_Proyecto) REFERENCES Proyecto(Id_Proyecto)
);

-- voy a crear la data para la base de datos TechSolutions 
-- Insertar datos en la tabla Departamento
INSERT INTO Departamento (Nombre, Ubicacion, Telefono) VALUES
("Tecnologías de la Información", "Edificio A - Piso 3", "3201112233"),
("Marketing", "Edificio B - Piso 2", "3105501122"),
("Recursos Humanos", "Edificio B - Piso 1", "3158897744"),
("Finanzas", "Edificio C - Piso 2", "3126678899"),
("Operaciones", "Planta Baja", "3207788991"),
("Legal", "Edificio C - Piso 1", "3115588662"),
("Investigación y Desarrollo", "Edificio D", "3169988123"),
("Calidad", "Edificio E", "3104455332"),
("Atención al Cliente", "Edificio F", "3007766554"),
("Comercial", "Edificio B - Piso 3", "3221100455"),
("Logística", "Bodega 1", "3147789001"),
("Infraestructura", "Data Center", "3021188445"),
("Seguridad", "Edificio A - Piso 1", "3117789123"),
("Compras", "Edificio C - Piso 3", "3186007744"),
("Gestión de Proyectos", "Edificio D - Piso 2", "3119900800"),
("Formación", "Edificio E - Piso 2", "3005522188"),
("Analítica de Datos", "Edificio A - Piso 4", "3174411223"),
("Relaciones Públicas", "Edificio B - Piso 4", "3125509911"),
("Auditoría", "Edificio C - Piso 4", "3113300442"),
("Sostenibilidad", "Edificio E - Piso 3", "3009911234"),
("Diseño", "Edificio D - Piso 1", "3157722001"),
("Ventas Internacionales", "Edificio B - Piso 5", "3108833221"),
("Soporte Técnico", "Edificio A - Piso 2", "3012288449"),
("Administración", "Edificio C - Piso 5", "3211103344"),
("Innovación", "Edificio D - Piso 3", "3189911220");

-- Insertar datos en la tabla Cargo
INSERT INTO Cargo (Nombre_Cargo, Salario_Base, Descripcion) VALUES
("Ingeniero de Software", 4500.00, "Desarrollo de aplicaciones"),
("Analista de Datos", 4200.00, "Análisis y BI"),
("Administrador de Redes", 3800.00, "Soporte e infraestructura"),
("Jefe de Proyecto", 6000.00, "Liderar proyectos"),
("Especialista DevOps", 4800.00, "Automatización y despliegue"),
("Diseñador UX/UI", 3500.00, "Diseño de interfaces"),
("Coordinador de RRHH", 3200.00, "Gestión de personal"),
("Contador", 4000.00, "Contabilidad y finanzas"),
("Asistente Administrativo", 2500.00, "Tareas administrativas"),
("Ejecutivo de Ventas", 3000.00, "Ventas y relaciones"),
("Especialista de Calidad", 3700.00, "Control de calidad"),
("Abogado Corporativo", 5500.00, "Asesoría legal"),
("Analista de Compras", 3100.00, "Procura y compras"),
("Soporte Técnico Nivel 1", 2200.00, "Atención a usuarios"),
("Soporte Técnico Nivel 2", 3000.00, "Soporte avanzado"),
("Líder de Innovación", 6200.00, "Estrategia de innovación"),
("Especialista SEO", 2800.00, "Marketing digital"),
("Técnico Logístico", 2600.00, "Operaciones de logística"),
("Gerente Comercial", 7000.00, "Dirección comercial"),
("Auditor Interno", 4300.00, "Revisiones y auditoría"),
("Especialista en Seguridad", 4100.00, "Seguridad física y lógica"),
("Project Manager Junior", 3300.00, "Gestión de proyectos junior"),
("Trainer/Formador", 2900.00, "Capacitación interna"),
("Coordinador de Proyectos", 3900.00, "Coordinación transversal"),
("Ingeniero QA", 3600.00, "Pruebas y aseguramiento");

-- Insertar datos en la tabla Empleado
INSERT INTO Empleado (Nombre, Segundo_Nombre, Apellido, Segundo_Apellido, Sexo, Fecha_Nacimiento, Fecha_Contratacion, Email, Id_Departamento, Id_Cargo) VALUES
("Alejandro", "Luis", "Martínez", "Gómez", "M", "1988-03-12", "2019-06-01", "alejandro.martinez@techsolutions.com", 1, 1),
("María", "Isabel", "Mendoza", "Pérez", "F", "1992-07-22", "2021-02-10", "maria.mendoza@techsolutions.com", 1, 2),
("Carlos", "Andrés", "Muñoz", "Ramos", "M", "1985-11-05", "2020-05-20", "carlos.munoz@techsolutions.com", 11, 3),
("Laura", "Beatriz", "Morales", "Sánchez", "F", "1995-09-30", "2022-09-01", "laura.morales@techsolutions.com", 2, 17),
("Javier", "Pablo", "González", "Torres", "M", "1989-01-15", "2018-03-12", "javier.gonzalez@techsolutions.com", 4, 8),
("Natalia", "Camila", "Marín", "Díaz", "F", "1997-04-18", "2020-11-02", "natalia.marin@techsolutions.com", 1, 5),
("Fernando", "José", "Mejía", "Lozano", "M", "1990-12-09", "2019-08-15", "fernando.mejia@techsolutions.com", 5, 10),
("Sofía", "Lucía", "Martín", "Suarez", "F", "1998-06-03", "2022-01-20", "sofia.martin@techsolutions.com", 2, 6),
("Diego", "Esteban", "Marín", "Ruiz", "M", "1987-10-27", "2016-04-05", "diego.marin@techsolutions.com", 1, 16),
("Valentina", "Andrea", "Mora", "Hernández", "F", "1993-02-14", "2021-07-09", "valentina.mora@techsolutions.com", 3, 7),
("Raúl", "Eduardo", "Moreno", "Castillo", "M", "1984-05-30", "2015-09-12", "raul.moreno@techsolutions.com", 4, 9),
("Camila", "Sofia", "Márquez", "Vega", "F", "1996-08-11", "2020-03-03", "camila.marquez@techsolutions.com", 6, 11),
("Andrés", "Felipe", "Molina", "Cruz", "M", "1991-12-25", "2019-10-10", "andres.molina@techsolutions.com", 16, 16),
("Mariana", "Patricia", "Meza", "Ortiz", "F", "1986-04-01", "2017-06-18", "mariana.meza@techsolutions.com", 7, 12),
("Pablo", "Ricardo", "Mota", "Pineda", "M", "1994-11-17", "2021-12-01", "pablo.mota@techsolutions.com", 8, 13),
("Daniela", "Carolina", "Montoya", "Gil", "F", "1999-03-21", "2023-01-10", "daniela.montoya@techsolutions.com", 9, 14),
("Jorge", "Manuel", "Mesa", "Perdomo", "M", "1983-07-02", "2014-05-05", "jorge.mesa@techsolutions.com", 10, 19),
("Isabella", "Noelia", "Mendoza", "López", "F", "1990-10-10", "2018-09-09", "isabella.mendoza@techsolutions.com", 1, 21),
("Ricardo", "Luis", "Márin", "Campos", "M", "1992-01-01", "2020-02-02", "ricardo.marin@techsolutions.com", 12, 22),
("Patricia", "Elena", "Márin", "Suárez", "F", "1982-06-06", "2013-11-11", "patricia.marin@techsolutions.com", 13, 23),
("Santiago", "Diego", "Mendoza", "Ruiz", "M", "1996-09-09", "2021-03-15", "santiago.mendoza@techsolutions.com", 14, 24),
("Monica", "Yamile", "Mendoza", "Henao", "F", "1994-12-12", "2022-06-06", "monica.mendoza@techsolutions.com", 15, 25),
("Hector", "Raúl", "Mora", "Salazar", "M", "1980-02-02", "2010-10-10", "hector.mora@techsolutions.com", 1, 4),
("Laura", "Mar", "Méndez", "Navarro", "F", "1991-05-05", "2019-09-09", "laura.mendez@techsolutions.com", 1, 1),
("Daniel", "Ramiro","Molina","Salazar","M", "1993-07-08","2019-08-07","daniel.molina@gmail.com",1,4);

-- Insertar datos en la tabla Proyecto
INSERT INTO Proyecto (Nombre_Proyecto, Fecha_Inicio, Fecha_Fin, Estado) VALUES
("Plataforma Web Corporativa", "2024-01-15", "2024-06-30", "Cerrado"),
("App Móvil Cliente", "2024-03-01", "2025-02-28", "En Progreso"),
("Migración a Cloud", "2023-10-01", "2024-12-31", "En Progreso"),
("Implementación BI", "2024-05-10", "2024-11-30", "Planificado"),
("Integración API", "2024-02-01", "2024-08-15", "Cerrado"),
("Portal Soporte", "2025-01-05", "2025-06-30", "Planificado"),
("Automatización CI/CD", "2023-09-01", "2024-03-31", "Cerrado"),
("Proyecto IoT Piloto", "2024-07-01", "2025-01-31", "En Progreso"),
("ERP Implementación", "2022-05-01", "2023-12-31", "Cerrado"),
("Campaña SEO 2025", "2025-02-01", "2025-08-01", "Planificado"),
("Centro de Datos Redesign", "2023-01-10", "2024-06-15", "Cerrado"),
("Chatbot Atención", "2024-09-01", "2025-04-30", "En Progreso"),
("Portal Proveedores", "2024-04-01", "2024-10-01", "Cerrado"),
("Proyecto Seguridad 2025", "2025-03-01", "2025-09-30", "Planificado"),
("Data Warehouse", "2023-06-01", "2024-06-30", "Cerrado"),
("Onboarding Digital", "2024-11-01", "2025-02-28", "En Progreso"),
("Rediseño UX", "2024-08-01", "2024-11-30", "En Progreso"),
("Integración Pagos", "2024-01-01", "2024-05-31", "Cerrado"),
("Optimización Cloud", "2024-10-01", "2025-04-30", "Planificado"),
("Proyecto Sustentable", "2023-03-01", "2024-03-31", "Cerrado"),
("Campaña Social Media", "2024-05-01", "2024-09-30", "Cerrado"),
("Mejora QA Automatizado", "2024-02-15", "2024-07-15", "Cerrado"),
("Sistema de Inventarios", "2024-06-01", "2024-12-31", "En Progreso"),
("Prueba de Penetración", "2025-01-15", "2025-03-15", "Planificado"),
("Implementación CRM", "2023-07-01", "2024-01-31", "Cerrado");

-- Insertar datos en la tabla Empleado_Proyecto
INSERT INTO Empleado_Proyecto (Id_Empleado, Id_Proyecto, Rol, Fecha_Entrada, Fecha_Salida) VALUES
(1, 1, "Desarrollador Backend", "2024-01-15", "2024-06-30"),
(2, 2, "Científico de Datos", "2024-03-01", NULL),
(3, 3, "Administrador de Redes", "2023-10-01", "2024-12-31"),
(4, 4, "Especialista SEO", "2024-05-10", NULL),
(5, 5, "Contador Proyecto", "2024-02-01", "2024-08-15"),
(6, 2, "DevOps", "2024-03-01", NULL),
(7, 6, "Ejecutivo de Ventas", "2025-01-05", NULL),
(8, 7, "QA Tester", "2023-09-01", "2024-03-31"),
(9, 8, "Ingeniero IoT", "2024-07-01", NULL),
(10, 9, "Analista BI", "2022-05-01", "2023-12-31"),
(11, 10, "Especialista Marketing", "2025-02-01", NULL),
(12, 11, "Ingeniero Infraestructura", "2023-01-10", "2024-06-15"),
(13, 12, "Desarrollador Frontend", "2024-09-01", NULL),
(14, 13, "Analista de Compras", "2024-04-01", "2024-10-01"),
(15, 14, "Especialista Seguridad", "2025-03-01", NULL),
(16, 15, "Arquitecto DW", "2023-06-01", "2024-06-30"),
(17, 16, "UX Designer", "2024-11-01", NULL),
(18, 17, "Especialista SEO", "2024-08-01", "2024-11-30"),
(19, 18, "Técnico Logístico", "2024-01-01", "2024-05-31"),
(20, 19, "Gerente Comercial", "2024-10-01", NULL),
(21, 20, "Auditor", "2023-03-01", "2024-03-31"),
(22, 21, "Soporte Técnico", "2024-05-01", "2024-09-30"),
(23, 22, "PM Junior", "2024-02-15", "2024-07-15"),
(24, 23, "Formador", "2024-06-01", "2024-12-31"),
(25, 24, "Coordinador de Proyectos", "2025-01-15", "2025-03-15"),
(1, 2, "Líder Técnico", "2024-03-01", NULL),
(2, 4, "Soporte Analítico", "2024-05-10", NULL),
(3, 11, "Infra Support", "2023-01-10", NULL),
(4, 10, "Marketing Analyst", "2025-02-01", NULL),
(5, 1, "Finance Lead", "2024-01-15", "2024-06-30"),
(6, 7, "DevOps Support", "2023-09-01", "2024-03-31"),
(7, 9, "Sales Rep", "2022-05-01", NULL),
(8, 12, "QA Automation", "2024-09-01", NULL),
(9, 16, "Cloud Engineer", "2024-11-01", NULL),
(10, 21, "Social Media", "2024-05-01", NULL),
(11, 18, "Logistics Tech", "2024-01-01", NULL),
(12, 20, "Auditor Assistant", "2023-03-01", "2024-03-31"),
(13, 5, "Frontend Dev", "2024-02-01", "2024-08-15"),
(14, 22, "PM Support", "2024-02-15", NULL);

